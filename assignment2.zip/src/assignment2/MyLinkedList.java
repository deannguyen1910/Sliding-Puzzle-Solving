package assignment2;

import java.util.NoSuchElementException;

/**
 *
 * This is a generic class representing a list of objects.
 * The operations on the list are as follows:
 * - adding and removing elements from the left and from the right.
 * - reversing the list
 * - obtaining the middle element
 * - getting the size of the list
 *
 * **All operations must run in O(1) time.**
 */
public class MyLinkedList<T> {
	private Node head;
	private int size = 0;
	public Node tail;
	public Node middle;
	private boolean isReverse = false;

	/**
	 * If the Linked List is reversed, it is simply doing reverse. E.g, it is reversed, then do insert
	 * left means it should insert right.
	 * So, for that, if it is reverse then if I want to addleft, I will call addRight. However, there is
	 * an infinite loop. E.g, addLeft calls addRight and addRight calls addLeft, and beyond :D.
	 * So use the isTwisted is for a confirmation that was called once only.
	 * True means that we haven't done as it is twisted :d
	 * False means we have done or default value.
	 */
	private boolean isTwisted = false;
	public Integer pos_mid = 0; // count from 0

	/**
	 * The constructor creates an empty list
	 */
	public MyLinkedList() {}

	private void fetchMiddle(){
		if (pos_mid == size / 2) return;
		if (size == 2){
			middle = tail;
			pos_mid = 1;
			return;
		}
		if (pos_mid < size / 2){
			middle = middle.next;
			pos_mid += 1;
			return;
		}
		if (pos_mid > size / 2){
			middle = middle.prev;
			pos_mid -= 1;
			return;
		}
	}

	/**
	 * Adds the new item to the left of the list.
	 */
	public void addLeft(T item) {
		if(!isReverse || isTwisted) {
			head = new Node(item, head, null);
			size += 1;
			if (tail == null) {
				tail = head;
				middle = tail;
			} else {
				head.next.prev = head;
				pos_mid += 1;
				fetchMiddle();
			}
		}else{
			isTwisted = true;
			addRight(item);
			isTwisted = false;
		}
	}

	/**
	 * Adds the new item to the right of the list.
	 */
	public void addRight(T item) {
		if(!isReverse || isTwisted) {
			if (tail != null) {
				tail = new Node(item, null, tail);
				tail.prev.next = tail;
				size += 1;
				fetchMiddle();
				return;
			} else {
				this.addLeft(item);
			}
		}else{
			isTwisted = true;
			addLeft(item);
			isTwisted = false;
		}
	}

	/**
	 * Removes the leftmost item from the list and returns it.
	 * If the list is empty, throws NoSuchElementException.
	 */
	 public T removeLeft(){
		 if (size == 1) {
			 T temp = head.value;
			 reset();
			 return temp;
		 }
		 if(!isReverse || isTwisted) {
			 if (isEmpty()) throw new NoSuchElementException("The Linked List is empty.");
			 T temp = head.value;
			 head = head.next;
			 head.prev = null;
			 pos_mid -= 1;
			 size -= 1;
			 fetchMiddle();
			 isTwisted = false;
			 return temp;
		 }else{
			 isTwisted = true;
			 return removeRight();
		 }
	 }

	/**
	 * Removes the rightmost item from the list and returns it.
	 * If the list is empty, throws NoSuchElementException.
	 */
	 public T removeRight() {
		 if (size == 1) {
			 T temp = head.value;
			 reset();
			 return temp;
		 }
		 if(!isReverse || isTwisted) {
			 if (isEmpty()) throw new NoSuchElementException("The Linked List is empty.");
			 T temp = tail.value;
			 tail = tail.prev;
			 tail.next = null;
			 size -= 1;
			 fetchMiddle();
			 isTwisted = false;
			 return temp;
		 }else{
			 isTwisted = true;
			 return removeLeft();
		 }
	 }

	/**
	 * Reverses the list
	 */
	public void reverse() {
		isReverse = !isReverse;
	}

	/**
	 * Returns the item in the middle of the list.
	 * If the list is empty, throws NoSuchElementException.
	 */
	public T getMiddle() {
		if (isEmpty()) throw new NoSuchElementException("The Linked List is empty.");
		if (!isReverse) {
			return middle.value;
		}else{
			if (size / 2 - 1 != pos_mid && size != 1){
				return middle.prev.value;
			}else {
				return middle.value;
			}
		}
	}

	/**
	 * Returns the size of the list.
	 */
	public int size() {
		return size;
	}

	/**
	 * Returns true if list is empty, and returns false otherwise.
	 */
	public boolean isEmpty() {
		if (head == null) return true;
		else return false;
	}

	public String toString(){
		String tempOut = "";
		Node tempNode = head;
		while(tempNode != null){
			tempOut += tempNode.value + " ";
			tempNode = tempNode.next;
		}
		return tempOut;
	}

	public String toStringBackward(){
		String tempOut = "";
		Node tempNode = tail;
		while(tempNode != null){
			tempOut += tempNode.value + " ";
			tempNode = tempNode.prev;
		}
		return tempOut;
	}

	private void reset(){
		this.head = null;
		this.middle = null;
		this.tail = null;
		this.size = 0;
		this.isTwisted = false;
		this.pos_mid = 0; // count from 1
	}
	public class Node{
		public T value;
		Node next;
		public Node prev;

		public Node(){
			next = null;
			prev = null;
		}

		public Node(T value, Node next, Node prev){
			this.value = value;
			this.next = next;
			this.prev = prev;
		}
	}
}
