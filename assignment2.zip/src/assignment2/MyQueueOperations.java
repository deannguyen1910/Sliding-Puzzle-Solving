package assignment2;

import basicdatastructures.queue.*;
import basicdatastructures.stack.Stack;

import java.util.ArrayList;
import java.util.Iterator;

public class MyQueueOperations {
	/**
	 * Returns the number of elements in q.
	 */

	public static <T> int size(Queue<T> q) {
		int count = 0;
		QueueLinkedListBased<T> temp = new QueueLinkedListBased<T>();
		while (!q.isEmpty()){
			temp.enqueue(q.dequeue());
			count++;
		}

		while(!temp.isEmpty()){
			q.enqueue(temp.dequeue());
		}

		return count;
	}

	/**
	 * Returns a copy of orig. The items are copied from orig to the new queue using
	 * = operator. For the concrete type of the returned object, you may use either
	 * QueueArrayBased or QueueLinkedListBased, up to you.
	 */
	public static <T> Queue<T> clone(Queue<T> orig) {
		QueueLinkedListBased<T> temp = new QueueLinkedListBased<T>() , out = new QueueLinkedListBased<T>();

		while(!orig.isEmpty()){
			temp.enqueue(orig.dequeue());
		}
		while(!temp.isEmpty()){
			T tempElement;
			tempElement = temp.dequeue();
			out.enqueue(tempElement);
			orig.enqueue(tempElement);
		}

		return out;
	}

	/**
	 * Reverses the order of the elements in q.
	 */
	public static <T> void reverse(Queue<T> q) {
		ArrayList<T> temp = new ArrayList<T>();
		while(!q.isEmpty()){
			temp.add(0, q.dequeue());
		}

		Iterator<T> it = temp.iterator();
		while(it.hasNext()){
			q.enqueue(it.next());
		}
	}

	/**
	 * Checks if the two queues have the same items in the same order. The items in
	 * the queues are compared using == operator.
	 */
	public static <T> boolean areEqual(Queue<T> q1, Queue<T> q2) {
		Queue<T> temp1 = clone(q1);
		Queue<T> temp2 = clone(q2);
		if(size(temp1) != size(temp2)){
			return false;
		}
		while(!temp1.isEmpty()){
			if (temp1.dequeue() != temp2.dequeue()){
				return false;
			}
		}
		return true;
	}
}
